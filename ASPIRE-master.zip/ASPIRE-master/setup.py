from setuptools import setup

setup(
    name='aspire',
    version='1.0.0',
    install_requires=['gym', 'numpy', 'pandas']
)
